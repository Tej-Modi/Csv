import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Data } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private firestore: AngularFirestore) { }

  deletedata(data: any) {
    return this.firestore.doc('/import-csv/' + data['id']).delete();
  }

}
