import { Component, OnInit, ViewChild } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import * as Papa from 'papaparse';
import { ToastrService } from 'ngx-toastr';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {MatPaginator} from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Data } from '@angular/router';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { MatSort, } from '@angular/material/sort';
import { ngxCsv } from 'ngx-csv';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;
  file: any;
  csvData: Data[] = [];
  popup = false;
  popup1 = false;
  displayedColumns: string[] = ['FirstName', 'LastName', 'Email', 'Password', 'DOB','action'];
  csvFiles!: any[];
  Path = '/csv';
  DataObj: Data = {
    id: '',
    FirstName: '',
    LastName: '',
    Email: '',
    Password: '',
    DOB: ''
  };
  dataSource = new MatTableDataSource(this.csvData);
  registerForm: FormGroup = new FormGroup({});
  headers: any;
  mapped: any;

  constructor( private data: DataService, private router: Router, public dialog: MatDialog, private firestore: AngularFirestore, private toastr: ToastrService, private storage: AngularFireStorage) { }

  ngOnInit(): void {
    this.registerForm = new FormGroup({
      option1: new FormControl('', [Validators.required]),
      option2: new FormControl('', [Validators.required]),
      option3: new FormControl('', Validators.required),
      option4: new FormControl('', Validators.required),
      option5: new FormControl('', Validators.required),
    });
     this.getAllData()

  }

  async onSelectFile(event: any) {
    const file = event.target.files[0];
    if (file) {
      console.log(file)
      let path = `${this.Path}/${file.name}`
      const fileUpload = await this.storage.upload(path, file);
      console.log(fileUpload);
      const url = await fileUpload.ref.getDownloadURL()
      console.log(url) 
    }
    Papa.parse(file, {
      header: true,
      complete: (results) => {
        const data = results.data;
        for (let i = 0; i < data.length; i++) {
          const Data = data[i];
          this.firestore.collection('import-csv').add(Data)

        }
        this.toastr.success(data.length + ' Data Added Successfully');
        this.headers = data[0];
        this.mapped = Object.entries(this.headers).map(([value]) => ({ value }));
        this.popup1 = true;
      }
     
    });

  }

  downloadCsv() {
    new ngxCsv(this.csvData,'test');
  }
 

  getAll() {
    return this.firestore.collection('import-csv').snapshotChanges();
  }
   

  getAllData() {
    this.getAll().subscribe(
      (res) => {
        this.csvData = res.map((e: any) => {
          const data = e.payload.doc.data();
          data.id = e.payload.doc.id;
  
          console.log(data)
          return data;
        });
        this.dataSource.data = this.csvData;
        this.dataSource.paginator = this.paginator;
        console.log(this.paginator);
      },
      (err) => {
        this.toastr.error('Error while fetching student data');
      }
    );
  
  }
 
  deleteStudent(data:any) {
    if (
      window.confirm(
        'Are you sure you want to delete ' +
          data.FirstName +
          ' ' +
          data.LastName +
          ' ?'
      )
    ) {
      this.data.deletedata(data);
    }
    localStorage.setItem('studentList', JSON.stringify(this.DataObj))
    this.toastr.success('Data Deleted Successfully');
  }


  next() {
    if(this.registerForm.valid){
      const Array = (this.dataSource?.data).map((users: any) => {
        const unit = this.registerForm
        users.FirstName = users[unit.value.option1]
        users.LastName = users[unit.value.option2]
        users.Email = users[unit.value.option3]
        users.DOB = users[unit.value.option4]
        users.Password = users[unit.value.option5]
        return users;
      
      });
      this.popup=true;  
      this.popup1=false;
    return;
     
    }
}


  logout(){
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
    this.toastr.error('Logged Out')
  }

  
}


