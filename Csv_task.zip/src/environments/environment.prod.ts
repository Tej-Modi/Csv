export const environment = {
  firebase: {
    projectId: 'final-7dbd6',
    appId: '1:1022757380525:web:57d1b6242e9f2d2937c124',
    storageBucket: 'final-7dbd6.appspot.com',
    apiKey: 'AIzaSyDzHk25_OdLOXU1TDAe6a1KV2v7cCsFeYk',
    authDomain: 'final-7dbd6.firebaseapp.com',
    messagingSenderId: '1022757380525',
  },
  production: true
};
